# Railway Setup — GitHub Actions Auto-Deploy

## Krok 1: Utwórz Railway Token

1. Wejdź na [Railway Dashboard](https://railway.app/dashboard)
2. Kliknij swój projekt → **Settings** → **Tokens**
3. Kliknij **New Token**
4. Skopiuj token (np. `railway_xxxxxxxxxxxx`)

## Krok 2: Dodaj sekrety do GitHub

1. Wejdź do repo na GitHub
2. **Settings** → **Secrets and variables** → **Actions**
3. Kliknij **New repository secret**
4. Dodaj:

| Nazwa | Wartość |
|-------|---------|
| `RAILWAY_TOKEN` | Twój Railway token |
| `DATABASE_URL` | `mysql://user:pass@host:port/db` |
| `JWT_SECRET` | Losowy ciąg min. 32 znaków |

## Krok 3: Włącz GitHub Actions

Workflow jest już w `.github/workflows/deploy.yml` — działa automatycznie po pushu do `main`.

## Krok 4: Pierwszy deploy

```bash
git add .
git commit -m "Setup GitHub Actions auto-deploy"
git push origin main
```

GitHub Actions:
1. ✅ Test — instaluje zależności, type-check, build
2. 🚀 Deploy — wysyła na Railway
3. 🔔 Notify — status powiadomienie

## Krok 5: Sprawdź status

- **GitHub**: [Actions tab](https://github.com/YOUR_REPO/actions)
- **Railway**: [Dashboard](https://railway.app/dashboard) → Deployments

## Troubleshooting

### Problem: `RAILWAY_TOKEN` nie działa

```bash
# Sprawdź czy token jest poprawny
railway whoami

# Wygeneruj nowy token
railway login
```

### Problem: Build fails

```bash
# Sprawdź logi w GitHub Actions
# Lub lokalnie:
cd app
npm ci
npm run build
```

### Problem: Database migration fails

```bash
# Uruchom migracje ręcznie na Railway
railway run node dist/migrate-all.js
```

## Workflow

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Push to   │────→│    Test     │────→│   Deploy    │
│    main     │     │             │     │             │
└─────────────┘     │ • npm ci    │     │ • railway up│
                    │ • tsc       │     │ • migrate   │
                    │ • build     │     │ • seed      │
                    └─────────────┘     └─────────────┘
                                              │
                                              ▼
                                        ┌─────────────┐
                                        │   Railway   │
                                        │             │
                                        │  • Build    │
                                        │  • Deploy   │
                                        │  • Start    │
                                        └─────────────┘
```

## Zmienne środowiskowe na Railway

Ustaw w Railway Dashboard → Variables:

```
DATABASE_URL=mysql://...
JWT_SECRET=...
SEED_DEMO=false
MQTT_BROKER=mqtt://... (opcjonalnie)
```

## Przydatne komendy

```bash
# Logi z Railway
railway logs

# Status deployment
railway status

# Połącz z bazą
railway connect mysql

# Uruchom komendę na Railway
railway run node dist/seed-indykpol.js
```
