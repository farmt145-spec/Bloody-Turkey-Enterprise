import { farmRouter } from "./farm-router";
import { orgRouter } from "./org-router";
import { dailyRouter, feedProgramRouter } from "./daily-router";
import { createRouter, publicQuery } from "./middleware";
import { erpRouter, notificationsRouter } from "./erp-router";
import { analyticsRouter, aiRouter } from "./analytics-router";
import { nutritionRouter } from "./nutrition-router";
import { commandRouter } from "./command-router";
import { gapRouter } from "./gap-router";
import { transferRouter } from "./transfer-router";
import { workspaceRouter } from "./workspace-router";
import { slaughterRouter } from "./slaughter-router";
import { geneticsRouter } from "./genetics-router";
import { obchodRouter } from "./obchod-router";
import { normyRouter } from "./normy-router";
import { reportsRouter } from "./reports-router";
import { authRouter } from "./auth-router";
import { slaughterCostChainRouter } from "./slaughter-cost-chain";
import { slaughterReportsRouter } from "./slaughter-reports";
import { iotRouter } from "./iot-router";
import { digitalTwinRouter } from "./digital-twin";
import { slaughterEdiRouter } from "./slaughter-edi";
import { slaughterForecastRouter } from "./slaughter-forecast";
import { financeRouter } from "./finance-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  
  // Autentykacja
  auth: authRouter,
  slaughterCostChain: slaughterCostChainRouter,
  slaughterReports: slaughterReportsRouter,
  iot: iotRouter,
  digitalTwin: digitalTwinRouter,
  slaughterEdi: slaughterEdiRouter,
  slaughterForecast: slaughterForecastRouter,
  finance: financeRouter,
  workspace: workspaceRouter,
  farm: farmRouter,
  org: orgRouter,
  daily: dailyRouter,
  feedProgram: feedProgramRouter,
  erp: erpRouter,
  notifications: notificationsRouter,
  analytics: analyticsRouter,
  ai: aiRouter,
  nutrition: nutritionRouter,
  command: commandRouter,
  gap: gapRouter,
  transfer: transferRouter,
  slaughter: slaughterRouter,
  genetics: geneticsRouter,
  obchod: obchodRouter,
  normy: normyRouter,
  reports: reportsRouter,
});

export type AppRouter = typeof appRouter;
