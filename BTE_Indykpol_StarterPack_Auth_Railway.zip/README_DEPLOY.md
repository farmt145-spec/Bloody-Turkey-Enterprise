# BTE — Wdrożenie na Railway

## Zmiany w tej wersji

### Nowe pliki:
- `app/db/seed-domain-data.ts` — centralne dane hodowlane (normy, receptury, programy, choroby, leki, dostawcy)
- `app/db/seed-indykpol.ts` — idempotentny seed Indykpol S.A. z pełnymi danymi produkcyjnymi
- `app/db/seed-starter-pack.ts` — starter pack dla nowych firm (dane domenowe + przykładowy rzut)

### Zmodyfikowane pliki:
- `app/api/workspace-router.ts` — auto-provisioning Indykpol + createCompany z withStarterData
- `app/src/pages/FarmSelect.tsx` — checkbox "Dodaj przykładowe dane startowe"
- `app/deploy/start.sh` — automatyczny seed Indykpol przy starcie
- `app/package.json` — build z nowymi plikami seed

## Co dostajesz

| Dane | Indykpol (demo) | Nowa firma (starter pack) |
|------|-----------------|---------------------------|
| Linie genetyczne | 5 linii z 7-fazowymi normami | 5 linii z 7-fazowymi normami |
| Normy żywieniowe | białko, energia, lizyna, metionina | identyczne |
| Surowce paszowe | 22 surowce z pełnymi kartami | 22 surowce |
| Receptury | 3 receptury (Starter, Grower, Finisher) | 3 receptury |
| Programy żywieniowe | 2 programy (indory + indyczki) | 2 programy |
| Biblioteka chorób | 10 chorób z protokołami | 10 chorób |
| Leki | 8 leków z karencjami | 8 leków |
| Dostawcy | 10 dostawców | 10 dostawców |
| Rzuty z historią | ✓ pełna historia | 1 rzut 35-dniowy |
| Szczepienia | ✓ | ✓ podstawowe |
| Leczenia | ✓ | — |

## Deploy na Railway

### 1. Zmienne środowiskowe

W Railway → Variables:
```
DATABASE_URL=mysql://user:password@host:port/database
SEED_DEMO=false
```

### 2. Deploy

```bash
git add .
git commit -m "Domain data + Indykpol demo + starter pack + auto-provisioning"
git push origin main
```

Railway auto-deploy z Dockerfile.

### 3. Weryfikacja

Po deploy sprawdź logi:
```
== Bloody Turkey Enterprise — start ==
>> Migracje bazy danych...
>> Seed Indykpol (idempotentny)...
Tworzę Indykpol S.A. (demo)...
Seeduję dane domenowe dla firmy 1...
  ✓ 5 linii genetycznych z normami
  ✓ 22 surowców paszowych
  ✓ 3 receptur
  ✓ 2 programów żywieniowych
  ✓ 10 chorób w bibliotece
  ✓ 8 leków
  ✓ 10 dostawców
Indykpol S.A. gotowe: 2 fermy, X rzutów
>> Start serwera na porcie 3000
```

### 4. Test

1. Otwórz stronę — widzisz **Indykpol S.A. (DEMO)**
2. Kliknij → wybierz fermę → wybierz kurnik → widzisz rzuty z danymi
3. Wróć → **Dodaj własną firmę** (z zaznaczonym checkbox "dane startowe")
4. Nowa firma ma: normy, receptury, programy, 1 rzut 35-dniowy z historią
5. Indykpol niezmieniony — dane izolowane per companyId

## Idempotentność

- `ensureIndykpolDemo()` — sprawdza czy Indykpol istnieje, jeśli tak → pomija
- `seedDomainData()` — sprawdza czy firma ma linie genetyczne, jeśli tak → pomija
- `seedStarterPack()` — wywoływany tylko raz przy tworzeniu firmy
- Restart kontenera nie duplikuje danych


---

## Autentykacja (NOWE)

### Pliki autentykacji

| Plik | Opis |
|------|------|
| `app/api/auth-router.ts` | register, login, logout, me, changePassword, reset |
| `app/api/middleware.ts` | protectedQuery, adminQuery z JWT |
| `app/api/context.ts` | Rozszerzony kontekst z userem |
| `app/src/pages/Login.tsx` | Strona logowania/rejestracji |
| `app/src/components/AuthGuard.tsx` | Ochrona tras |
| `app/src/components/UserMenu.tsx` | Menu usera w headerze |
| `app/db/migrations/XXXX_add_auth.sql` | Migracja bazy |

### Zmienne środowiskowe

```
JWT_SECRET=twoj-dlugi-losowy-sekret-min-32-znakow
```

### Użycie w kodzie

```typescript
// Publiczne — bez logowania
publicQuery.query(async () => { ... })

// Chronione — wymaga zalogowania
protectedQuery.query(async ({ ctx }) => { 
  console.log(ctx.user.email) // dostęp do usera
})

// Admin — wymaga roli owner/admin
adminQuery.mutation(async ({ ctx }) => { ... })
```

### Role

| Rola | Uprawnienia |
|------|-------------|
| `owner` | Pełny dostęp + zarządzanie firmą |
| `admin` | Pełny dostęp do danych |
| `user` | Odczyt + edycja danych produkcyjnych |
| `viewer` | Tylko odczyt |

### Migracja bazy

Przed pierwszym deploy z auth, uruchom migrację:

```bash
# Lokalnie lub na Railway
mysql -u user -p database < app/db/migrations/XXXX_add_auth.sql
```

Lub dodaj do `migrate-all.ts` automatyczne wykonanie.

