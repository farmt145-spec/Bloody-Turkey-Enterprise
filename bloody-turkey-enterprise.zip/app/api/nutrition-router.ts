/* ============================================================
   AI NUTRITION LAB — wirtualne laboratorium żywienia.
   Symulator "co będzie jeśli…" na suwakach udziałów surowców,
   ekspert tłumaczący receptury, inteligentne porównanie i
   symulator całego rzutu. Liczone deterministycznie na realnych
   danych surowców z bazy (ceny, białko, energia, aminokwasy).
   ============================================================ */
import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as s from "@db/schema";
import { desc, eq } from "drizzle-orm";

const num = (v: unknown) => Number(v ?? 0);

type Mix = { ingredientId: number; percent: number }[];

/* Profil wartości odżywczych mieszanki (średnia ważona) */
function profileOf(items: { ing: s.FeedIngredient; percent: number }[]) {
  const sum = items.reduce((a, i) => a + i.percent, 0) || 1;
  const w = (fn: (i: s.FeedIngredient) => number) =>
    items.reduce((a, i) => a + (fn(i.ing) * i.percent) / sum, 0);
  return {
    protein: w((i) => num(i.proteinPct)),
    energy: w((i) => num(i.energyKcal)),
    lysine: w((i) => num(i.lysinePct)),
    methionine: w((i) => num(i.methioninePct)),
    fiber: w((i) => num(i.fiberPct)),
    fat: w((i) => num(i.fatPct)),
    calcium: w((i) => num(i.calciumPct)),
    phosphorus: w((i) => num(i.phosphorusPct)),
    costPerTon: w((i) => num(i.pricePerTon)),
  };
}

/* Wyniki produkcyjne przewidywane z profilu — model kalibrowany dla indyków */
export const AGE_GROUPS = {
  prestarter: { label: "Prestarter (0–14 d)", protein: 28, energy: 2850, lysine: 1.7, baseAdg: 45, days: 14 },
  starter: { label: "Starter (15–28 d)", protein: 26, energy: 2900, lysine: 1.6, baseAdg: 75, days: 28 },
  grower1: { label: "Grower I (29–56 d)", protein: 23, energy: 3000, lysine: 1.35, baseAdg: 105, days: 56 },
  grower2: { label: "Grower II (57–84 d)", protein: 20, energy: 3100, lysine: 1.1, baseAdg: 130, days: 84 },
  finisher1: { label: "Finisher I (85–112 d)", protein: 18, energy: 3200, lysine: 1.0, baseAdg: 150, days: 112 },
  finisher2: { label: "Finisher II (113+ d)", protein: 16.5, energy: 3250, lysine: 0.9, baseAdg: 155, days: 140 },
} as const;
export type AgeGroupKey = keyof typeof AGE_GROUPS;
// aliasy wstecznej zgodności
const ALIAS: Record<string, AgeGroupKey> = { grower: "grower2", finisher: "finisher1" };

function productionFromProfile(p: ReturnType<typeof profileOf>, ageGroupIn: AgeGroupKey | string) {
  const ageGroup = (ALIAS[ageGroupIn] ?? ageGroupIn) as AgeGroupKey;
  const g = AGE_GROUPS[ageGroup] ?? AGE_GROUPS.finisher1;
  const target = { protein: g.protein, energy: g.energy, lysine: g.lysine };
  const proteinFit = Math.min(p.protein / target.protein, 1.08);
  const lysineFit = Math.min(p.lysine / target.lysine, 1.1);
  const energyFit = Math.min(p.energy / target.energy, 1.06);
  const fiberPenalty = Math.max(0, (p.fiber - 5) * 0.012);
  const growthIndex = Math.min(proteinFit, lysineFit) * energyFit - fiberPenalty; // ~1.0 idealnie

  const baseAdg = g.baseAdg;
  const adgG = Math.max(baseAdg * growthIndex, 30);
  const fcr = Math.max(2.35 - (growthIndex - 1) * 0.55 + Math.max(0, 6 - p.fat) * 0.008, 1.7);
  const totalDays = Math.max(g.days, 30);
  const epef = totalDays >= 60 ? ((0.96 * (baseAdg * growthIndex * totalDays) / 1000) * 10000) / (totalDays * fcr) : ((0.96 * (baseAdg * growthIndex * totalDays) / 1000) * 10000) / (60 * fcr);
  const waterMl = adgG * 14 + p.fiber * 6 + (p.energy - 3000) * 0.04;
  const metabolicRisk = Math.min(Math.max((p.fat - 7) * 6 + Math.max(0, p.protein - target.protein - 2) * 8 + fiberPenalty * 400, 0), 100);
  const safety = Math.min(100 - metabolicRisk * 0.6 - Math.max(0, p.fiber - 6) * 5, 100);
  return { adgG, fcr, epef, waterMl, metabolicRisk, safety, growthIndex };
}

const mixInput = z.object({
  items: z.array(z.object({ ingredientId: z.number(), percent: z.number().min(0).max(100) })).min(1),
  ageGroup: z.enum(["prestarter", "starter", "grower1", "grower2", "finisher1", "finisher2", "grower", "finisher"]).default("finisher1"),
});

async function loadIngredients(db: ReturnType<typeof getDb>, mix: Mix) {
  const all = await db.select().from(s.feedIngredients);
  const map = new Map(all.map((i) => [i.id, i]));
  return mix
    .filter((m) => map.has(m.ingredientId) && m.percent > 0)
    .map((m) => ({ ing: map.get(m.ingredientId)!, percent: m.percent }));
}

function explainMix(items: { ing: s.FeedIngredient; percent: number }[], p: ReturnType<typeof profileOf>, prod: ReturnType<typeof productionFromProfile>, ageGroup: string) {
  const parts: string[] = [];
  const top = [...items].sort((a, b) => b.percent - a.percent).slice(0, 3);
  parts.push(`Mieszanka (${ageGroup}) opiera się na: ${top.map((t) => `${t.ing.name} ${t.percent.toFixed(0)}%`).join(", ")}.`);
  parts.push(`Profil: białko ${p.protein.toFixed(1)}%, energia ${p.energy.toFixed(0)} kcal, lizyna ${p.lysine.toFixed(2)}%, metionina ${p.methionine.toFixed(2)}%, włókno ${p.fiber.toFixed(1)}%, tłuszcz ${p.fat.toFixed(1)}%.`);
  if (p.lysine < 0.9) parts.push("⚠ Niedobór lizyny — rozważ większy udział śruty sojowej lub krystalicznej lizyny; każdy 0.1 p.p. niedoboru lizyny obniża ADG o ok. 8–12 g.");
  if (p.fiber > 5.5) parts.push("⚠ Podwyższone włókno zwiększa pobór wody i wilgotność ściółki — dodatek enzymu ksylanazy poprawi wykorzystanie energii.");
  if (p.fat > 8) parts.push("⚠ Wysoki tłuszcz podnosi ryzyko metaboliczne i zjełczenia — zabezpiecz antyoksydantem.");
  parts.push(`Przewidywane: ADG ${prod.adgG.toFixed(0)} g/d, FCR ${prod.fcr.toFixed(2)}, EPEF ${prod.epef.toFixed(0)}, pobór wody ${prod.waterMl.toFixed(0)} ml/szt/d. Koszt tony: ${p.costPerTon.toFixed(0)} EUR.`);
  parts.push(`Poziom pewności rekomendacji: ${Math.round(88 + prod.safety * 0.1)}%.`);
  return parts.join(" ");
}

function scoreMix(p: ReturnType<typeof profileOf>, prod: ReturnType<typeof productionFromProfile>) {
  let score = 100;
  score -= Math.abs(prod.fcr - 2.3) * 18;
  score -= Math.max(0, 145 - prod.adgG) * 0.12;
  score -= Math.max(0, p.costPerTon - 420) * 0.04;
  score -= prod.metabolicRisk * 0.25;
  return Math.max(Math.min(Math.round(score), 100), 20);
}

export const nutritionRouter = createRouter({
  /* Symulator suwaków — błyskawiczna kalkulacja po stronie serwera */
  simulate: publicQuery.input(mixInput).query(async ({ input }) => {
    const db = getDb();
    const items = await loadIngredients(db, input.items);
    const p = profileOf(items);
    const prod = productionFromProfile(p, input.ageGroup);
    const total = items.reduce((a, i) => a + i.percent, 0);
    return {
      profile: p,
      production: prod,
      totalPercent: total,
      normalized: Math.abs(total - 100) < 0.5,
      costPerKgLive: (p.costPerTon / 1000) * prod.fcr,
      explanation: explainMix(items, p, prod, input.ageGroup),
      warnings: [
        ...(total > 100.5 ? [`Suma udziałów ${total.toFixed(0)}% — przekracza 100%, wartości znormalizowane`] : []),
        ...(total < 99.5 && total > 0 ? [`Suma udziałów ${total.toFixed(0)}% — uzupełnij do 100%`] : []),
      ],
    };
  }),

  /* Inteligentne porównanie receptur A vs B */
  compare: publicQuery
    .input(z.object({ a: mixInput.shape.items, b: mixInput.shape.items, ageGroup: mixInput.shape.ageGroup }))
    .query(async ({ input }) => {
      const db = getDb();
      const ia = await loadIngredients(db, input.a);
      const ib = await loadIngredients(db, input.b);
      const pa = profileOf(ia), pb = profileOf(ib);
      const ra = productionFromProfile(pa, input.ageGroup), rb = productionFromProfile(pb, input.ageGroup);
      const sa = scoreMix(pa, ra), sb = scoreMix(pb, rb);
      const reasons: string[] = [];
      if (Math.abs(ra.adgG - rb.adgG) > 3) reasons.push(ra.adgG > rb.adgG ? "wyższy potencjał wzrostu (ADG)" : "niższy potencjał wzrostu (ADG)");
      if (Math.abs(ra.fcr - rb.fcr) > 0.03) reasons.push(ra.fcr < rb.fcr ? "lepsza konwersja paszy" : "gorsza konwersja paszy");
      if (Math.abs(pa.lysine - pb.lysine) > 0.05) reasons.push(pa.lysine > pb.lysine ? "lepszy profil aminokwasów" : "słabszy profil aminokwasów");
      if (Math.abs(pa.costPerTon - pb.costPerTon) > 10) reasons.push(pa.costPerTon < pb.costPerTon ? "niższy koszt tony" : "wyższy koszt tony");
      if (Math.abs(ra.metabolicRisk - rb.metabolicRisk) > 5) reasons.push(ra.metabolicRisk < rb.metabolicRisk ? "mniejsze ryzyko metaboliczne" : "większe ryzyko metaboliczne");
      return {
        a: { profile: pa, production: ra, score: sa },
        b: { profile: pb, production: rb, score: sb },
        verdict: sa === sb ? "Receptury równoważne" : sa > sb ? `Receptura A lepsza (${sa}/100 vs ${sb}/100)` : `Receptura B lepsza (${sb}/100 vs ${sa}/100)`,
        reasons,
      };
    }),

  /* Symulator całego rzutu dla danej mieszanki */
  batchSimulation: publicQuery
    .input(z.object({ items: mixInput.shape.items, ageGroup: mixInput.shape.ageGroup, birds: z.number().default(10000), days: z.number().default(140) }))
    .query(async ({ input }) => {
      const db = getDb();
      const items = await loadIngredients(db, input.items);
      const p = profileOf(items);
      const prod = productionFromProfile(p, input.ageGroup);
      const finalWeightKg = (prod.adgG * input.days) / 1000;
      const livability = 96 - prod.metabolicRisk * 0.05;
      const soldKg = input.birds * (livability / 100) * finalWeightKg;
      const feedKg = soldKg * prod.fcr;
      const feedCost = (feedKg / 1000) * p.costPerTon;
      const chickCost = input.birds * 1.36;
      const vetEnergyCost = soldKg * 0.18;
      const totalCost = feedCost + chickCost + vetEnergyCost;
      const pricePerKg = 4.9; // EUR/kg — cena kontraktowa żywca
      const revenue = soldKg * pricePerKg;
      const profit = revenue - totalCost;
      return {
        finalWeightKg, livability, adgG: prod.adgG, fcr: prod.fcr, epef: prod.epef,
        mortalityPct: 100 - livability, feedTons: feedKg / 1000, waterTons: (soldKg / prod.fcr) * 0 + (input.birds * prod.waterMl * input.days) / 1e6,
        feedCostEur: feedCost, totalCostEur: totalCost, costPerKgLive: totalCost / Math.max(soldKg, 1),
        revenueEur: revenue, grossMarginEur: profit, ammoniaTons: (feedKg * p.protein * 0.16 * 0.35 * 17 / 14) / 1e6,
        certaintyPct: Math.round(85 + prod.safety * 0.12),
      };
    }),

  /* Raport ekspercki dla istniejącej receptury z bazy */
  expertReport: publicQuery.input(z.object({ recipeId: z.number() })).query(async ({ input }) => {
    const db = getDb();
    const [r] = await db.select().from(s.recipes).where(eq(s.recipes.id, input.recipeId));
    if (!r) return null;
    const items = await db.select().from(s.recipeItems).where(eq(s.recipeItems.recipeId, r.id));
    const ings = await db.select().from(s.feedIngredients);
    const map = new Map(ings.map((i) => [i.id, i]));
    const mix = items.map((it) => ({ ing: map.get(it.ingredientId)!, percent: num(it.percent) })).filter((x) => x.ing);
    const p = profileOf(mix);
    const prod = productionFromProfile(p, "finisher");
    return {
      recipe: r,
      composition: mix.map((m) => ({ name: m.ing.name, percent: m.percent, pricePerTon: num(m.ing.pricePerTon) })),
      profile: p,
      production: prod,
      score: scoreMix(p, prod),
      report: explainMix(mix, p, prod, r.ageGroup),
      alternatives: mix
        .filter((m) => num(m.ing.pricePerTon) > p.costPerTon)
        .map((m) => {
          const cheaper = ings.filter((i) => num(i.proteinPct) >= num(m.ing.proteinPct) * 0.85 && num(i.pricePerTon) < num(m.ing.pricePerTon) * 0.9 && i.id !== m.ing.id);
          return cheaper.length ? `Częściowa zamiana ${m.ing.name} na ${cheaper[0].name} obniży koszt tony o ~${((num(m.ing.pricePerTon) - num(cheaper[0].pricePerTon)) * m.percent / 100).toFixed(0)} EUR` : null;
        })
        .filter(Boolean),
    };
  }),

  /* Lista surowców do panelu suwaków */
  ingredients: publicQuery.query(async () => {
    return getDb().select().from(s.feedIngredients).orderBy(desc(s.feedIngredients.stockTons));
  }),
});
