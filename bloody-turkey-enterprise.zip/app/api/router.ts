import { authRouter } from "./auth-router";
import { farmRouter } from "./farm-router";
import { orgRouter } from "./org-router";
import { dailyRouter, feedProgramRouter } from "./daily-router";
import { createRouter, publicQuery } from "./middleware";
import { erpRouter, notificationsRouter } from "./erp-router";
import { analyticsRouter, aiRouter } from "./analytics-router";
import { nutritionRouter } from "./nutrition-router";
import { commandRouter } from "./command-router";
import { gapRouter } from "./gap-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  farm: farmRouter,
  org: orgRouter,
  daily: dailyRouter,
  feedProgram: feedProgramRouter,
  erp: erpRouter,
  notifications: notificationsRouter,
  analytics: analyticsRouter,
  ai: aiRouter,
  nutrition: nutritionRouter,
  command: commandRouter,
  gap: gapRouter,
});

export type AppRouter = typeof appRouter;
