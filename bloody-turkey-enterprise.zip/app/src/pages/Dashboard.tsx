import { useMemo } from "react";
import { trpc } from "@/providers/trpc";
import { ComposableMap, Geographies, Geography, Marker, ZoomableGroup } from "react-simple-maps";
import { feature } from "topojson-client";
import countriesTopo from "world-atlas/countries-110m.json";
import { fmtNum, fmtTons, countryFlag, countryName, num } from "@/lib/geo";
import { Bird, Scale, Gauge, Skull, TrendingUp, Warehouse, Globe2, AlertTriangle, Flame } from "lucide-react";
import { Link } from "react-router";

const EUROPE_IDS = new Set([
  "250", "276", "620", "616", "724", "380", "528", "826", "208", "203", "348", "040", "756", "752", "578",
  "372", "300", "642", "100", "703", "705", "191", "246", "233", "428", "440", "804", "112", "498", "807",
  "070", "008", "499", "688", "400", "352", "492", "438", "056", "020", "470", "674", "031",
]);
// nazwy → iso numeryczne: powyżej klucze numeryczne (110m używa id numerycznych)
const EUROPE_NUM = new Set([
  250, 276, 620, 616, 724, 380, 528, 826, 208, 203, 348, 40, 756, 752, 578, 372, 300, 642, 100, 703,
  705, 191, 246, 233, 428, 440, 804, 112, 498, 807, 70, 8, 499, 688, 400, 352, 492, 438, 56, 20, 470, 674, 31,
]);

const geographies = (feature as any)(countriesTopo as any, (countriesTopo as any).objects.countries).features.filter(
  (f: any) => EUROPE_NUM.has(Number(f.id)),
);
void EUROPE_IDS;

function KpiCard({ icon: Icon, label, value, sub, accent }: {
  icon: any; label: string; value: string; sub?: string; accent?: boolean;
}) {
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
      <div className="flex items-center gap-2 text-zinc-400">
        <Icon className={`h-4 w-4 ${accent ? "text-red-400" : ""}`} />
        <span className="text-xs font-medium uppercase tracking-wider">{label}</span>
      </div>
      <div className="mt-2 text-2xl font-bold text-zinc-50">{value}</div>
      {sub && <div className="mt-1 text-xs text-zinc-500">{sub}</div>}
    </div>
  );
}

export default function Dashboard() {
  const kpis = trpc.farm.dashboard.kpis.useQuery();
  const mapData = trpc.farm.dashboard.mapData.useQuery();
  const alerts = trpc.farm.dashboard.alerts.useQuery();

  const maxBirds = useMemo(
    () => Math.max(1, ...(mapData.data ?? []).map((f) => f.activeBirds)),
    [mapData.data],
  );

  const k = kpis.data;
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard operacyjny</h1>
        <p className="text-sm text-zinc-500">
          Bloody Turkey Group S.A. — {k?.countriesCount ?? "…"} krajów · {k?.farmsCount ?? "…"} ferm · czas rzeczywisty
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard icon={Bird} label="Ptaki w chowie" value={k ? fmtNum(k.activeBirds) : "…"} sub={`${k?.activeBatches ?? "…"} aktywnych rzutów`} accent />
        <KpiCard icon={Scale} label="Biomasa" value={k ? fmtTons(k.biomassTons) : "…"} sub="cała grupa, EUR" />
        <KpiCard icon={Gauge} label="FCR (ważone)" value={k ? k.avgFcr.toFixed(2) : "…"} sub="kg paszy / kg przyrostu" />
        <KpiCard icon={Skull} label="Śmiertelność" value={k ? `${k.avgMortality.toFixed(2)}%` : "…"} sub="średnia z rzutów" />
        <KpiCard icon={TrendingUp} label="EPEF / PEI" value={k ? fmtNum(k.avgEpef) : "…"} sub="indeks efektywności" />
        <KpiCard icon={Warehouse} label="Fermy" value={k ? String(k.farmsCount) : "…"} sub={`${k?.countriesCount ?? "…"} krajów Europy`} />
        <KpiCard icon={Globe2} label="Zasięg" value={k ? `${k.countriesCount}` : "…"} sub="kraje UE + UK" accent />
        <KpiCard icon={Flame} label="Alerty" value={alerts.data ? String(alerts.data.length) : "…"} sub="wymagają uwagi" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4 lg:col-span-2">
          <h2 className="mb-1 text-sm font-semibold uppercase tracking-wider text-zinc-400">
            Mapa ferm — Europa
          </h2>
          <div className="relative">
            <ComposableMap
              projection="geoMercator"
              projectionConfig={{ center: [12, 52], scale: 620 }}
              width={800}
              height={520}
              style={{ width: "100%", height: "auto" }}
            >
              <ZoomableGroup>
                <Geographies geography={geographies}>
                  {({ geographies: geos }: any) =>
                    geos.map((geo: any) => (
                      <Geography
                        key={geo.rsmKey}
                        geography={geo}
                        fill="#1f2937"
                        stroke="#374151"
                        strokeWidth={0.5}
                        style={{
                          default: { outline: "none" },
                          hover: { fill: "#374151", outline: "none" },
                          pressed: { outline: "none" },
                        }}
                      />
                    ))
                  }
                </Geographies>
                {(mapData.data ?? []).map((f) => {
                  const r = 4 + (f.activeBirds / maxBirds) * 12;
                  return (
                    <Marker key={f.id} coordinates={[num(f.lng), num(f.lat)]}>
                      <circle r={r + 4} fill="#ef4444" opacity={0.15} />
                      <circle r={r} fill="#ef4444" opacity={0.75} stroke="#fecaca" strokeWidth={1} />
                      <text
                        y={-r - 6}
                        textAnchor="middle"
                        className="fill-zinc-300"
                        style={{ fontSize: 10, fontWeight: 600 }}
                      >
                        {countryFlag(f.countryCode)} {fmtNum(f.activeBirds / 1000, 0)}k
                      </text>
                    </Marker>
                  );
                })}
              </ZoomableGroup>
            </ComposableMap>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
            {(mapData.data ?? []).map((f) => (
              <div key={f.id} className="rounded-lg bg-zinc-800/60 px-3 py-2 text-xs">
                <span className="mr-1">{countryFlag(f.countryCode)}</span>
                <span className="font-medium">{f.city}</span>
                <span className="ml-1 text-zinc-500">({countryName(f.countryCode)})</span>
                <div className="mt-0.5 text-zinc-400">
                  {fmtNum(f.activeBirds)} szt. · {fmtTons(f.biomassTons)}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-400">
            Centrum alertów
          </h2>
          <div className="max-h-[560px] space-y-2 overflow-y-auto pr-1">
            {(alerts.data ?? []).map((a, i) => (
              <div
                key={i}
                className={`rounded-lg border p-3 text-sm ${
                  a.type === "critical"
                    ? "border-red-900/60 bg-red-950/40"
                    : a.type === "warning"
                      ? "border-amber-900/60 bg-amber-950/30"
                      : "border-zinc-800 bg-zinc-900/60"
                }`}
              >
                <div className="flex items-center gap-2 font-medium">
                  <AlertTriangle
                    className={`h-4 w-4 ${a.type === "critical" ? "text-red-400" : "text-amber-400"}`}
                  />
                  {a.title}
                </div>
                <p className="mt-1 text-xs text-zinc-400">{a.detail}</p>
              </div>
            ))}
            {alerts.data?.length === 0 && (
              <div className="rounded-lg border border-zinc-800 bg-zinc-900/60 p-4 text-sm text-zinc-500">
                Brak aktywnych alertów. Wszystkie parametry w normie.
              </div>
            )}
          </div>
          <Link
            to="/produkcja"
            className="block rounded-lg bg-red-600/15 px-4 py-3 text-center text-sm font-medium text-red-400 transition-colors hover:bg-red-600/25"
          >
            Przejdź do produkcji →
          </Link>
        </div>
      </div>
    </div>
  );
}
